<?php

$conf['account_suffix']     = '';
$conf['base_dn']            = '';
$conf['domain_controllers'] = '';
$conf['sso']                = 0;
$conf['sso_charset']        = '';
$conf['admin_username']     = '';
$conf['admin_password']     = '';
$conf['real_primarygroup']  = 0;
$conf['use_ssl']            = 0;
$conf['use_tls']            = 0;
$conf['debug']              = 0;
$conf['expirywarn']         = 0;
$conf['additional']         = '';
$conf['update_name']        = 0;
$conf['update_mail']        = 0;
$conf['update_pass']        = 1;
$conf['recursive_groups']   = 0;
