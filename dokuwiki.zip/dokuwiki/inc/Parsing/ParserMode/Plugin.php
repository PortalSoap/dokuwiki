<?php

namespace dokuwiki\Parsing\ParserMode;

/**
 * @fixme do we need this anymore or could the syntax plugin inherit directly from abstract mode?
 */
abstract class Plugin extends AbstractMode {}
